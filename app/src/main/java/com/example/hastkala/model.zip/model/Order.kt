package com.example.hastkala.model

class Order(
    var OrderId:Int,
    var ProductId:Int,
    var SizeId:String,
    val Name:String,
    val Details:String,
    val Purchaseqty:String,
    val TotalPrice:String,
    val Price:String,
    val Imagepath:String,
    val Image:String,
    val Status:String,
    val Size:String
)