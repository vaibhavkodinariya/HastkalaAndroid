package com.example.hastkala.model

class Category(
    var id: Int,
    var name: String,
    var imagepath:String,
    var image: String)