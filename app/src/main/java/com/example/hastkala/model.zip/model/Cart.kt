package com.example.hastkala.model

class Cart(
    val OrderId:Int,
    val ProductId:Int,
    val Quantity:String,
    val Totalprice:String,
    val Sizeid:String,
    val Name:String,
    val Price:String,
    val Details:String,
    val Imagepath:String,
    val Image: String,
    val Size:String?
)