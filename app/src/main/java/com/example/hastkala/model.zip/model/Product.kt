package com.example.hastkala.model

class Product(
    var id: Int,
    var name: String,
    var details:String,
    var price: Int,
    var path:String,
    var image: String
)