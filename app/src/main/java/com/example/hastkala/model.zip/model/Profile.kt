package com.example.hastkala.model

class Profile(
    var Name:String,
    var MobileNumber:String,
    var Address:String,
    var State:String,
    var Gender:String,
    var Pincode:String,
    var Email:String
)