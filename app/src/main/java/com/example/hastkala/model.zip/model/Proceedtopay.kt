package com.example.hastkala.model

class Proceedtopay(
    val OrderID:Int?,
    val DateTime:String?,
    val ProductID: Int,
    val Name: String,
    val Details: String,
    val Price:String,
    val Purchaseqty:String,
    val ImagesPath:String,
    val Image:String,
    val TotalPrice:String,
    val SizeID:String?,
    val Size:String
)